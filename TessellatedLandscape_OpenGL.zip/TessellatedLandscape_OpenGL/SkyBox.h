#pragma once
#include <vector>
#include "glm/mat4x4.hpp"
#include "Object.h"
#include "stb/stb_image.h"


class SkyBox : public Object
{

private:
	unsigned int textureID, cubeTexture = -1;
	std::string base = "C:/Users/Casa/source/repos/TessellatedLandscape_OpenGL/Resources/SkyBox";
	std::vector<std::string> faces
	{
		base + "/right.jpg",
		base + "/left.jpg",
		base + "/top.jpg",
		base + "/bottom.jpg",
		base + "/front.jpg",
		base + "/back.jpg"
	};

	float skyboxVertices[36*3] = {
		// positions          
		-1.0f,  1.0f, -1.0f,
		-1.0f, -1.0f, -1.0f,
		1.0f, -1.0f, -1.0f,
		1.0f, -1.0f, -1.0f,
		1.0f,  1.0f, -1.0f,
		-1.0f,  1.0f, -1.0f,

		-1.0f, -1.0f,  1.0f,
		-1.0f, -1.0f, -1.0f,
		-1.0f,  1.0f, -1.0f,
		-1.0f,  1.0f, -1.0f,
		-1.0f,  1.0f,  1.0f,
		-1.0f, -1.0f,  1.0f,

		1.0f, -1.0f, -1.0f,
		1.0f, -1.0f,  1.0f,
		1.0f,  1.0f,  1.0f,
		1.0f,  1.0f,  1.0f,
		1.0f,  1.0f, -1.0f,
		1.0f, -1.0f, -1.0f,

		-1.0f, -1.0f,  1.0f,
		-1.0f,  1.0f,  1.0f,
		1.0f,  1.0f,  1.0f,
		1.0f,  1.0f,  1.0f,
		1.0f, -1.0f,  1.0f,
		-1.0f, -1.0f,  1.0f,

		-1.0f,  1.0f, -1.0f,
		1.0f,  1.0f, -1.0f,
		1.0f,  1.0f,  1.0f,
		1.0f,  1.0f,  1.0f,
		-1.0f,  1.0f,  1.0f,
		-1.0f,  1.0f, -1.0f,

		-1.0f, -1.0f, -1.0f,
		-1.0f, -1.0f,  1.0f,
		1.0f, -1.0f, -1.0f,
		1.0f, -1.0f, -1.0f,
		-1.0f, -1.0f,  1.0f,
		1.0f, -1.0f,  1.0f
	};

	unsigned int loadCubemap(std::vector<std::string> faces);

public:
	SkyBox();
	~SkyBox();
	void drawObject(glm::mat4 view, glm::mat4 perspective);

};

