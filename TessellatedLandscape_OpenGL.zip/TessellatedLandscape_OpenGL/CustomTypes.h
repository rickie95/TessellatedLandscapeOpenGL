#pragma once

typedef struct {
	unsigned int x, y, z;
}uint3;

typedef struct {
	float x, y, z;
}float3;

typedef struct {
	float x, y;
}float2;